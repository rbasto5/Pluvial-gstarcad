# Duall Pluvial e Reuso — versão 1.1

Plugin .NET para GstarCAD 2025 Windows. Abra o painel com `PLUVIAL` após carregar `Duall.Pluvial.1.1.dll` por `NETLOAD`. Mantenha `D-Prumada-Plu.dwg` na mesma pasta da DLL. Use uma sessão nova do GstarCAD para evitar comandos de versões anteriores carregadas simultaneamente.

## Bloco e sistema

O botão **+ Prumada** importa o modelo fornecido pelo usuário com o nome de definição **D-Prumada-Plu**. A propriedade dinâmica de diâmetro continua sendo **PRUMADA**. O arquivo modelo conserva a geometria original; o nome de definição é atribuído na importação pelo plugin.

Na aba **Projeto / elemento**, escolha **Sistema da prumada**:

| Sistema | Layer da referência da prumada |
| --- | --- |
| Pluvial | D-HID-PLU-TET |
| Reuso | D-HID-APV-TET |

As fórmulas e o dimensionamento são iguais. A escolha é armazenada no bloco e acompanha sua cópia para outro DWG. O layer é aplicado na inserção e ao salvar/recalcular. Se o layer não existir, o plugin o cria; se já existir, preserva suas propriedades. Não altera automaticamente os layers de calhas ou coletores.

O plugin não renomeia nem modifica definições antigas D-PRUMADA presentes no projeto. Insira uma nova D-Prumada-Plu pelo painel para utilizar esta versão. Os dados antigos podem ser lidos e suas contribuições recebidas pelo botão de união; o destino atualizado deve ser o novo bloco. Registros de versões anteriores sem sistema são interpretados como Pluvial.

## Fluxo

1. Preencha obra, município, intensidade, período de retorno e fonte da chuva. Confirme desenho em metros.
2. Escolha Pluvial ou Reuso e insira a prumada, ou selecione uma D-Prumada-Plu existente.
3. Em **Contribuições**, informe nome, tipo, pavimentos atendidos e acréscimo por área/pavimento. Selecione os contornos fechados para atribuí-los ao elemento.
4. Para pavimento tipo, gere a lista de pavimentos antes de selecionar a área. O multiplicador afeta somente essas contribuições.
5. Copie o bloco normalmente entre DWGs. No destino, selecione-o pelo painel para continuar ou receber contribuições de outros elementos.
6. Para trocar Pluvial/Reuso em uma prumada existente, selecione-a, escolha o sistema e clique **Salvar no bloco e recalcular**.

## Validação e limites atuais

- Versão 1.1 compilada; 20 verificações automatizadas aprovadas, incluindo persistência do sistema, compatibilidade de registros antigos e igualdade do cálculo.
- Testes nativos da versão 1.1 no GstarCAD 2025 aprovaram importação dinâmica como D-Prumada-Plu, alteração para 150 mm, aplicação dos dois layers, edição do comprimento da calha, cópia entre bancos DWG e salvamento/reabertura com registros preservados. A janela foi inspecionada visualmente. Consulte o relatório de testes incluído.
- Diâmetros verticais seguem a tabela de referência da planilha do usuário; a verificação pelos ábacos da NBR 10844 permanece pendente.
- Calha retangular verifica capacidade uniforme por Manning. As alças próprias dependem do plugin carregado. A rotina da alça de comprimento foi exercitada pela API nativa; o arraste interativo e a alça de largura ainda não foram verificados.
- Coletor horizontal usa Manning com lâmina de 2/3 do diâmetro interno. Conferir a correspondência entre diâmetro interno calculado e produto comercial.
- Cópias mantêm registros, sem sincronização automática com o arquivo de origem. Contornos sobrepostos e acréscimos geométricos exigem conferência.
